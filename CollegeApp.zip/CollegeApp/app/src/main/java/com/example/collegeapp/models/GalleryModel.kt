package com.example.collegeapp.models

data class GalleryModel(
    val category: String = "",
    val images: List<String> = emptyList()
)
