package com.example.collegeapp.models

data class DashboardItemModel(

    val title: String,
    val routes: String

)
