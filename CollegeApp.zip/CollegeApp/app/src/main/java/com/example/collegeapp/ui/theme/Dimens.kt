package com.example.collegeapp.ui.theme

import androidx.compose.ui.unit.sp

val TITLE_SIZE = 18.sp
val TEXT_SIZE = 16.sp
val SMALL_TEXT_SIZE = 14.sp